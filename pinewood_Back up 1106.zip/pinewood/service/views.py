from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.shortcuts import redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Profile
from django.contrib import messages
from django.contrib.auth.models import User
'''
@login_required
def service_home(request):
    profile = Profile.objects.get(user=request.user)
    context = {
        'user_name': profile.user.username,  # Fetch the name from the user profile
    }
    return render(request, 'service.html', context)
'''
@login_required
def profile_view(request):
    profile = Profile.objects.get(user=request.user)

    if request.method == 'POST':
        # Retrieve updated information from the form and save it
        profile.user.username = request.POST.get('name', profile.user.username)
        profile.gender = request.POST.get('gender', profile.gender)
        profile.living_place = request.POST.get('living_place', profile.living_place)
        profile.description = request.POST.get('description', profile.description)

        # Save the user and profile updates
        profile.user.save()
        profile.save()

        return redirect('profile')  # Redirect to the same page to refresh data

    context = {
        'profile': profile,
        'user_name': profile.user.username,
    }
    return render(request, 'profile.html', context)

def online_service(request):
    return render(request, 'online_service.html')

def chatting_service(request):
    return render(request, 'chatting.html')

def map_service(request):
    return render(request, 'map_service.html')
'''
@login_required
def service_home(request):
    return render(request, 'service.html')  # Make sure this matches your template path
'''

@login_required
def service_home(request):
    # Fetch the profile for the current user
    try:
        profile = Profile.objects.get(user=request.user)
    except Profile.DoesNotExist:
        profile = None  # or handle it as appropriate for your application

    context = {
        'profile': profile,
    }
    return render(request, 'service.html', context)

from service.models import Profile

def map_service(request):
    # Check if we should clear the session data (triggered by the "click here" link)
    if request.method == 'GET' and 'clear_session' in request.GET:
        if 'locations' in request.session:
            del request.session['locations']
        return redirect('map_detail')  # Redirect to map_detail after clearing session

    if request.method == 'POST':
        # Retrieve selected locations from the form
        locations = request.POST.getlist('location')  # List of selected locations
        if not locations:
            messages.warning(request, "No locations selected. Proceeding without data.")
            return redirect('map_detail')
        else:
            # Save locations in session to pass them to map_detail
            request.session['locations'] = locations
            return redirect('map_detail')
    return render(request, 'map_service.html')


def map_detail(request):
    # Retrieve locations from session, defaulting to None if not found
    locations = request.session.get('locations', None)
    default_covid_areas = [
        "Adelaide City North of Wakefield st, East of KingWilliam St",
        "Adelaide City South of Grote St, West of KingWilliam",
        "Rose Park",
        "Ovingham",
        "Mile End",
        "Unley",
    ]

    is_at_risk = False
    if locations:
        # Check if any of the user’s locations match COVID-affected areas
        is_at_risk = any(location in default_covid_areas for location in locations)

    context = {
        'locations': locations,
        'is_at_risk': is_at_risk,
        'covid_areas': default_covid_areas,
    }
    return render(request, 'map_detail.html', context)

def ask_doctor(request):
    # Add your view logic here
    return render(request, 'ask_doctor.html')

'''
def profile_view(request):
    profile = Profile.objects.get(user=request.user)

    if request.method == 'POST':
        # Fetch form data
        name = request.POST.get('name', profile.user.username)
        gender = request.POST.get('gender', profile.gender)
        living_place = request.POST.get('living_place', profile.living_place)
        description = request.POST.get('description', profile.description)

        # Update the profile fields
        profile.user.username = name
        profile.gender = gender
        profile.living_place = living_place
        profile.description = description

        # Save changes to both the user and profile
        profile.user.save()
        profile.save()

        messages.success(request, "Profile updated successfully.")
        return redirect('profile')  # Redirect to reload with updated data

    return render(request, 'profile.html', {'profile': profile})
'''