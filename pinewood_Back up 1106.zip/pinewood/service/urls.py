from django.urls import path
from . import views

urlpatterns = [
    path('', views.service_home, name='service_home'),  # Main service page
    path('online/', views.online_service, name='online_service'),  # Online Service page
    path('chat/', views.chatting_service, name='chatting_service'),  # Chatting Service page
    path('map/', views.map_service, name='map_service'),  # Map Service page
    path('profile/', views.profile_view, name='profile'),
    path('', views.service_home, name='service_home'),
    path('map_service/', views.map_service, name='map_service'),
    path('map_detail/', views.map_detail, name='map_detail'),
    path('ask_doctor/', views.ask_doctor, name='ask_doctor'),
]

